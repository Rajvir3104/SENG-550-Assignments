SELECT * FROM deliveries
WHERE status != 'Delivered';