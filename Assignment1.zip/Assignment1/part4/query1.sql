-- List all customers with their contact details.
SELECT * FROM customers;